# mysh — Mini Linux Shell with Background Job Management

A small but complete Unix shell written in C (~1,900 lines, zero dependencies) whose focus is
**job control**: running commands in the background, stopping and resuming them, tracking them in a
job table, and being told when they finish — the same model used by bash/zsh, built from raw
POSIX system calls (`fork`, `execvp`, `pipe`, `dup2`, `setpgid`, `tcsetpgrp`, `waitpid`, `kill`).

```
mysh$ sleep 300 &
[1] 4121
mysh[1 running]$ ./build_project         # long-running foreground job...
^Z
[2]+  Stopped         ./build_project
mysh[1 running, 1 stopped]$ bg
[2]+ ./build_project &
mysh[2 running]$ jobs -l
[1]-  Running         sleep 300 &
       pgid=4121  elapsed=00:00:42
       |- pid 4121  running
[2]+  Running         ./build_project &
       pgid=4133  elapsed=00:00:09
       |- pid 4133  running
mysh[2 running]$ kill %1
[1]-  Terminated      sleep 300
```

## Build & run

Requires Linux, `gcc`/`clang`, `make`. (Python 3 only for the terminal tests.)

```bash
make            # builds ./mysh   (compiles clean with -Wall -Wextra -Wpedantic)
./mysh          # interactive shell
./mysh -c 'sleep 1 & wait; echo done'   # one-shot
./mysh script.sh                        # run a file
make test       # 67 scripted tests + 12 pseudo-terminal job-control tests
```

## Features

| Area | Supported |
|---|---|
| Commands | `cmd args`, `$PATH` lookup, exit status in `$?`, `127` not found / `126` not executable |
| Pipelines | `a \| b \| c` — each pipeline is **one job** with one process group |
| Redirection | `< f`, `> f`, `>> f`, `2> f`, `2>> f`, `2>&1` |
| Sequencing | `a ; b`, `a &` (background) |
| Expansion | `$VAR`, `${VAR}`, `$?`, `$$`, `$!`, `~`, globbing `* ? [..]`, quoting `'..'` `".."` `\x`, `#` comments |
| **Job control** | `jobs [-lprs]`, `fg`, `bg`, `kill`, `wait`, `disown`, **Ctrl+Z**, **Ctrl+C**, job specs `%n %% %+ %- %str %?str` |
| Shell | `cd [-]`, `pwd`, `export`, `unset`, `history`, `!!`, `!N`, `help`, `exit` |

### Novel / beyond-the-basics features

1. **Asynchronous job notification** — while you sit at an idle prompt, finished and stopped
   background jobs are reported immediately (`poll()` with a timeout + non-blocking reap), not only
   after the next keypress.
2. **Live job-aware prompt** — `mysh[2 running, 1 stopped]$` shows the job table state at a glance.
3. **Rich `jobs -l`** — per-job elapsed wall time, process-group id, and per-process state
   (`running` / `stopped` / `exited(n)` / `killed by SIGx`) for every stage of a pipeline.
4. **Terminal-mode save/restore** — a job stopped with Ctrl+Z (e.g. `vim`) has its `termios`
   saved, and restored on `fg`; the shell's own settings are restored after every job.
5. **Smart `kill` on stopped jobs** — a `SIGTERM` to a stopped job is followed by `SIGCONT`, so it
   actually dies instead of sitting stopped with the signal pending.
6. **Safe exit semantics** — `exit` with stopped jobs warns once (like bash); on exit remaining jobs
   get `SIGHUP`, and `disown` exempts a job. Background jobs never steal terminal input.
7. **Lazy expansion with whole-line syntax pre-check** — `false; echo $?` prints `1` (each
   pipeline is expanded *just before it runs*) yet a syntax error anywhere on the line runs
   *nothing*, matching bash.

## Architecture

```
                    ┌────────────────────────── main.c ──────────────────────────┐
  keyboard ──────►  │ read_line(): prompt + poll(200ms) ── idle? ─► jobs_reap()   │
                    │                                              jobs_notify() │
                    │ history_expand()  ──►  process_line()                      │
                    └───────────────┬────────────────────────────────────────────┘
                                    │ 1. parse_line()  (syntax check whole line)
                                    │ 2. parse_next()  (expand + parse ONE pipeline)
                                    ▼
                    ┌──────────── parser.c ────────────┐
                    │ lexer: quotes, $VAR, ~, glob     │
                    │ parser: Pipeline{Command[]}      │
                    └───────────────┬──────────────────┘
                                    │ Pipeline
                                    ▼
                    ┌──────────── executor.c ──────────────────────────────┐
                    │ single builtin?  ── yes ─► run in shell (cd, fg, ..) │
                    │        │ no                                          │
                    │        ▼                                             │
                    │ for each stage: pipe() → fork() → setpgid()          │
                    │   child: reset signals, dup2, redirs, execvp         │
                    │ job_create() → foreground? tcsetpgrp + job_wait      │
                    │              → background? print "[n] pid", return   │
                    └───────┬─────────────────────────────┬────────────────┘
                            │                             │
                            ▼                             ▼
              ┌──────── jobs.c ────────┐     ┌──── builtins.c ─────┐
              │ Job table (linked list) │◄────│ jobs fg bg kill wait │
              │ Job{id,pgid,Proc[],     │     │ disown cd pwd exit   │
              │  state,exit,termios}    │     │ export unset history │
              │ waitpid() → state       │     └──────────────────────┘
              └─────────────────────────┘
```

### Job state machine

```
            fork+exec                Ctrl+Z / SIGSTOP
   (new) ───────────────► RUNNING ────────────────────► STOPPED
                            │  ▲                           │
              all procs     │  └──────── bg / fg / ────────┘
              exited/killed │            SIGCONT
                            ▼
                          DONE ──► reported once ("[1]+ Done ...") ──► removed
```
A job's state is *derived* from its processes: all exited → `DONE`; any running → `RUNNING`;
otherwise `STOPPED`. This makes pipelines (several processes per job) work with no special cases.

### Key design decisions

| Decision | Reason |
|---|---|
| One **process group per pipeline** | `kill(-pgid)` and the terminal's Ctrl+C/Ctrl+Z reach every stage at once |
| `setpgid()` in **both** parent and child | Removes the fork/exec race (whichever runs first wins; the other is harmless) |
| Shell ignores `SIGTSTP/SIGTTIN/SIGTTOU/SIGQUIT`, **handles** `SIGINT` without `SA_RESTART` | Shell can't be stopped by Ctrl+Z; Ctrl+C at the prompt just redraws; `wait` is interruptible |
| **No work inside signal handlers** — children are reaped by polling `waitpid(WNOHANG)` | The job table is a plain linked list with no locks and no async-signal-safety hazards |
| Signals reset to `SIG_DFL` in the child before `exec` | Ignored dispositions would otherwise be inherited and make jobs un-stoppable |
| Builtins run **in the shell process** only when they're a lone foreground command | `cd`/`fg`/`exit` must affect the shell; in a pipeline or with `&` they run in a child, like bash |
| Redirections for in-shell builtins use saved/restored fds | `cd /tmp > out` and `jobs > file` work without leaking descriptors |
| Non-interactive mode has no terminal control | Scripts/tests behave like `bash script`: background jobs get `/dev/null` stdin and `kill %n` signals each pid |

## Source layout

```
src/shell.h        shared types + module interfaces
src/main.c         init, signals, REPL, prompt, async notification, history expansion
src/parser.c       lexer (quoting/expansion/glob) + pipeline parser
src/executor.c     fork/exec, pipes, redirections, process groups, foreground wait
src/jobs.c         job table, state tracking, printing, job specs
src/builtins.c     jobs fg bg kill wait disown cd pwd exit export unset history help
src/util.c         allocation helpers, history storage (~/.mysh_history)
tests/run_tests.sh scripted tests (67)
tests/test_jobcontrol.py   pseudo-terminal tests of Ctrl+Z / fg / bg / Ctrl+C (12)
docs/PROJECT_REPORT.md     report, rubric mapping, presentation outline
```

## Testing

* `tests/run_tests.sh` — 67 black-box tests: parsing/quoting/expansion, pipes, every redirection
  form, error handling and exit codes, builtins, background jobs (`jobs`, `kill`, `wait`, `disown`,
  signals → exit status 143/137), pipelines as jobs, 20 simultaneous jobs, zombie check.
* `tests/test_jobcontrol.py` — 12 tests run inside a **pseudo-terminal** and type real
  Ctrl+Z / Ctrl+C keystrokes: stop, `bg`, `fg`, `fg %n` selection, kill of a stopped job,
  shell survives Ctrl+C/Ctrl+Z, async `Done` notice with no keypress, exit warning, `!!`.
* Built and run clean under `-fsanitize=address,undefined`.

## Known limitations (honest scope)

No `&&`/`||`, subshells `( )`, here-docs, shell functions/loops/`if`, aliases, or line editing /
tab completion (the terminal's own line discipline is used). Shell variables are environment
variables (`export`). These are natural extensions; see `docs/PROJECT_REPORT.md`.
