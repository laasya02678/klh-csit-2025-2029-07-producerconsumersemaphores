#!/usr/bin/env python3
"""
Interactive job-control tests for mysh.

Job control only exists on a real terminal, so these tests run mysh inside a
pseudo-terminal and type keystrokes (including Ctrl+Z = \\x1a and
Ctrl+C = \\x03) exactly like a user would.

Run from the project root:   python3 tests/test_jobcontrol.py
"""
import os
import pty
import re
import select
import signal
import subprocess
import sys
import time

SHELL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "mysh")
passed = failed = 0


class Session:
    def __init__(self):
        env = dict(os.environ, MYSH_PROMPT="$ ", HOME="/tmp/mysh_test_home")
        os.makedirs(env["HOME"], exist_ok=True)
        self.pid, self.fd = pty.fork()
        if self.pid == 0:
            os.execve(SHELL, [SHELL], env)
        self.buf = ""

    def send(self, s):
        os.write(self.fd, s.encode())

    def read_until(self, pattern, timeout=5.0):
        """Read until regex `pattern` matches the unread output; returns it."""
        end = time.time() + timeout
        while time.time() < end:
            m = re.search(pattern, self.buf)
            if m:
                out, self.buf = self.buf[: m.end()], self.buf[m.end():]
                return out
            r, _, _ = select.select([self.fd], [], [], 0.1)
            if r:
                try:
                    data = os.read(self.fd, 4096)
                except OSError:
                    break
                self.buf += data.decode(errors="replace").replace("\r", "")
        raise TimeoutError(f"timeout waiting for /{pattern}/; got: {self.buf!r}")

    def close(self):
        # kill the shell's children first so no test job is left orphaned
        try:
            kids = subprocess.run(["pgrep", "-P", str(self.pid)], capture_output=True,
                                  text=True).stdout.split()
            for k in kids:
                try:
                    os.kill(int(k), signal.SIGKILL)
                except ProcessLookupError:
                    pass
        except FileNotFoundError:
            pass
        try:
            os.kill(self.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            os.waitpid(self.pid, 0)
        except ChildProcessError:
            pass


def check(name, fn):
    global passed, failed
    s = Session()
    try:
        s.read_until(r"\$ ")
        fn(s)
        passed += 1
        print(f"  \033[32mPASS\033[0m  {name}")
    except Exception as e:  # noqa: BLE001
        failed += 1
        print(f"  \033[31mFAIL\033[0m  {name}\n        {e}")
    finally:
        s.close()


def t_ctrl_z_stops(s):
    s.send("sleep 30\n")
    time.sleep(0.4)
    s.send("\x1a")                                   # Ctrl+Z
    s.read_until(r"\[1\]\+\s+Stopped\s+sleep 30")
    s.read_until(r"\$ ")
    s.send("jobs\n")
    s.read_until(r"\[1\]\+\s+Stopped\s+sleep 30")


def t_bg_resumes(s):
    s.send("sleep 30\n")
    time.sleep(0.4)
    s.send("\x1a")
    s.read_until(r"Stopped")
    s.read_until(r"\$ ")
    s.send("bg\n")
    s.read_until(r"\[1\]\+ sleep 30 &")
    s.read_until(r"\$ ")
    s.send("jobs\n")
    s.read_until(r"\[1\]\+\s+Running\s+sleep 30 &")


def t_fg_then_ctrl_c(s):
    s.send("sleep 30\n")
    time.sleep(0.4)
    s.send("\x1a")
    s.read_until(r"Stopped")
    s.read_until(r"\$ ")
    s.send("fg\n")
    s.read_until(r"sleep 30\n")
    time.sleep(0.4)
    s.send("\x03")                                   # Ctrl+C kills the job
    s.read_until(r"\$ ")
    s.send("echo status=$?\n")
    s.read_until(r"status=130")
    s.read_until(r"\$ ")
    s.send("jobs\n")
    s.send("echo marker\n")
    out = s.read_until(r"marker")
    assert "sleep" not in out, "job should be gone after Ctrl+C"


def t_ctrl_c_spares_shell(s):
    s.send("sleep 30\n")
    time.sleep(0.4)
    s.send("\x03")
    s.read_until(r"\$ ")
    s.send("echo alive\n")
    s.read_until(r"alive")


def t_ctrl_z_does_not_stop_shell(s):
    s.send("\x1a")                                   # at the prompt: ignored
    s.send("echo still-here\n")
    s.read_until(r"still-here")


def t_async_done_notice(s):
    s.send("sleep 0.5 &\n")
    s.read_until(r"\[1\] \d+")                       # "[1] pid"
    s.read_until(r"\$ ")
    # do NOT press Enter: the notice must appear on its own
    s.read_until(r"\[1\]\+?\s+Done\s+sleep 0.5", timeout=4)


def t_fg_of_bg_job_finishes(s):
    s.send("sleep 1 &\n")
    s.read_until(r"\[1\] \d+")
    s.read_until(r"\$ ")
    s.send("fg %1\n")
    s.read_until(r"sleep 1\n")
    s.read_until(r"\$ ", timeout=4)                  # returns when sleep ends
    s.send("echo rc=$?\n")
    s.read_until(r"rc=0")


def t_two_stopped_jobs_select(s):
    for cmd in ("sleep 31", "sleep 32"):
        s.send(cmd + "\n")
        time.sleep(0.4)
        s.send("\x1a")
        s.read_until(r"Stopped")
        s.read_until(r"\$ ")
    s.send("fg %1\n")                                # pick the older one
    s.read_until(r"sleep 31\n")
    time.sleep(0.3)
    s.send("\x03")
    s.read_until(r"\$ ")
    s.send("jobs\n")
    s.read_until(r"\[2\]\+\s+Stopped\s+sleep 32")


def t_kill_stopped_job(s):
    s.send("sleep 30\n")
    time.sleep(0.4)
    s.send("\x1a")
    s.read_until(r"Stopped")
    s.read_until(r"\$ ")
    s.send("kill %1\n")                              # TERM + implicit CONT
    s.read_until(r"\[1\]\+?\s+Terminated\s+sleep 30", timeout=4)


def t_prompt_shows_counts(s):
    s.send("export MYSH_PROMPT=\n")                  # use the dynamic prompt
    s.send("unset MYSH_PROMPT\n")
    s.send("sleep 30 &\n")
    s.read_until(r"mysh\[1 running\]\$ ")
    s.send("kill %1\n")


def t_exit_warns_about_stopped(s):
    s.send("sleep 30\n")
    time.sleep(0.4)
    s.send("\x1a")
    s.read_until(r"Stopped")
    s.read_until(r"\$ ")
    s.send("exit\n")
    s.read_until(r"There are stopped jobs")
    s.read_until(r"\$ ")
    s.send("exit\n")                                 # second exit forces it
    s.read_until(r"exit\n")


def t_history_bang(s):
    s.send("echo first-cmd\n")
    s.read_until(r"first-cmd\n")
    s.read_until(r"\$ ")
    s.send("!!\n")
    s.read_until(r"echo first-cmd\nfirst-cmd")


TESTS = [
    ("Ctrl+Z stops the foreground job", t_ctrl_z_stops),
    ("bg resumes a stopped job in the background", t_bg_resumes),
    ("fg + Ctrl+C terminates job, $? = 130", t_fg_then_ctrl_c),
    ("Ctrl+C kills the job but not the shell", t_ctrl_c_spares_shell),
    ("Ctrl+Z at the prompt does not stop the shell", t_ctrl_z_does_not_stop_shell),
    ("async 'Done' notification without pressing Enter", t_async_done_notice),
    ("fg on a running background job", t_fg_of_bg_job_finishes),
    ("fg %n selects the right stopped job", t_two_stopped_jobs_select),
    ("kill on a stopped job terminates it", t_kill_stopped_job),
    ("prompt shows running/stopped job counts", t_prompt_shows_counts),
    ("exit warns about stopped jobs (once)", t_exit_warns_about_stopped),
    ("history expansion !!", t_history_bang),
]

if __name__ == "__main__":
    if not os.path.exists(SHELL):
        sys.exit("build the shell first: make")
    print("== Interactive job control (pseudo-terminal) ==")
    for name, fn in TESTS:
        check(name, fn)
    print(f"\nPassed: {passed}   Failed: {failed}")
    sys.exit(1 if failed else 0)
