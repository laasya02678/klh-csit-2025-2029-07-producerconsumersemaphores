#!/usr/bin/env bash
# Automated tests for mysh (non-interactive features).
# Usage: ./tests/run_tests.sh      (run from the project root, after `make`)

cd "$(dirname "$0")/.." || exit 1
SH=./mysh
PASS=0; FAIL=0
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

# t NAME EXPECTED_STDOUT COMMAND...
t() {
    local name=$1 expected=$2 cmd=$3
    local actual
    actual=$($SH -c "$cmd" 2>&1)
    if [[ "$actual" == "$expected" ]]; then
        PASS=$((PASS+1)); printf '  \033[32mPASS\033[0m  %s\n' "$name"
    else
        FAIL=$((FAIL+1)); printf '  \033[31mFAIL\033[0m  %s\n        expected: %q\n        actual:   %q\n' "$name" "$expected" "$actual"
    fi
}
# tm NAME REGEX COMMAND  (regex match)
tm() {
    local name=$1 re=$2 cmd=$3
    local actual
    actual=$($SH -c "$cmd" 2>&1)
    if [[ "$actual" =~ $re ]]; then
        PASS=$((PASS+1)); printf '  \033[32mPASS\033[0m  %s\n' "$name"
    else
        FAIL=$((FAIL+1)); printf '  \033[31mFAIL\033[0m  %s\n        pattern: %s\n        actual:  %q\n' "$name" "$re" "$actual"
    fi
}

echo "== Parsing, quoting, expansion =="
t "simple command"            "hello"          "echo hello"
t "double quotes keep spaces" "a  b"           'echo "a  b"'
t "single quotes are literal" '$HOME'          "echo '\$HOME'"
t "backslash escape"          "a b"            'echo a\ b'
t "env var expansion"         "bar"            'export FOO=bar; echo $FOO'
t "\${VAR} expansion"         "bar!"           'export FOO=bar; echo ${FOO}!'
t "unset var vanishes"        "[x]"            'echo [x]$NOPE'
t "\$? after false"           "1"              'false; echo $?'
t "\$? after success"         "0"              'true; echo $?'
t "tilde expansion"           "$HOME"          'echo ~'
t "comment ignored"           "hi"             'echo hi # comment'
t "sequence with ;"           $'a\nb'          'echo a; echo b'
touch "$TMP/f1.txt" "$TMP/f2.txt"
t "glob expansion"            "$TMP/f1.txt $TMP/f2.txt" "echo $TMP/f*.txt"
t "unmatched glob literal"    "$TMP/*.zzz"     "echo $TMP/*.zzz"

echo "== Pipes and redirection =="
t "two-stage pipe"            "3"              'echo a b c | wc -w'
t "three-stage pipe"          "2"              'printf "b\na\nb\n" | sort | uniq | wc -l'
t "redirect >"                "hi"             "echo hi > $TMP/o; cat $TMP/o"
t "redirect >> appends"       $'1\n2'          "echo 1 > $TMP/a; echo 2 >> $TMP/a; cat $TMP/a"
t "redirect <"                "hi"             "echo hi > $TMP/i; cat < $TMP/i"
t "redirect 2>"               "1"              "ls /nonexistent_dir 2> $TMP/e; wc -l < $TMP/e"
t "redirect 2>&1 into pipe"   "1"              'ls /nonexistent_dir 2>&1 | wc -l'
t "missing input file"        "mysh: /nonexistent: No such file or directory" 'cat < /nonexistent'

echo "== Errors and exit codes =="
t "command not found"         "mysh: nosuchcmd: command not found" 'nosuchcmd'
t "not-found status is 127"   "127"            'nosuchcmd 2>/dev/null; echo $?'
t "syntax: leading pipe"      "mysh: syntax error near '|'" '| wc'
t "syntax: missing target"    "mysh: syntax error: missing redirection target" 'echo hi >'
t "syntax error runs nothing" "mysh: syntax error near ';'" 'echo SHOULD_NOT_RUN; ; echo x'
t "unterminated quote"        "mysh: unterminated double quote" 'echo "abc'
t "exit code propagates"      "7"              'sh -c "exit 7"; echo $?'
$SH -c 'exit 5'; rc=$?
[[ $rc -eq 5 ]] && { PASS=$((PASS+1)); echo "  PASS  exit builtin sets exit code"; } || { FAIL=$((FAIL+1)); echo "  FAIL  exit builtin ($rc)"; }

echo "== Builtins =="
t "cd and pwd"                "/tmp"           'cd /tmp; pwd'
t "cd -"                      $'/tmp\n/'       'cd /tmp; cd /; cd - >/dev/null; pwd; cd /; pwd' 
t "cd bad dir"                "cd: /nope_dir: No such file or directory" 'cd /nope_dir'
t "builtin inside pipe"       "/tmp"           'cd /tmp; pwd | cat'
t "builtin redirect"          "/tmp"           "cd /tmp; pwd > $TMP/p; cat $TMP/p"

echo "== Background jobs =="
t "bg job runs; wait finishes" "done"          'sleep 0.2 & wait; echo done'
tm "jobs lists a running job"  '^\[1\]\+ +Running +sleep 5 &' 'sleep 5 & jobs; kill %1; wait'
t "wait returns job status"   "3"              'sh -c "sleep 0.1; exit 3" & wait %1; echo $?'
t "kill %1 then wait = 143"   "143"            'sleep 5 & kill %1; wait %1; echo $?'
t "kill -9 gives 137"         "137"            'sleep 5 & kill -9 %1; wait %1; echo $?'
t "kill -s TERM syntax"       "143"            'sleep 5 & kill -s TERM %1; wait %1; echo $?'
t "kill by pid (\$!)"          "143"            'sleep 5 & kill $!; wait %1; echo $?'
tm "\$! is set"                '^[0-9]+$'      'sleep 0.1 & echo $!; wait'
t "multiple jobs numbered"    $'[1]- Running\n[2]+ Running' \
    'sleep 5 & sleep 5 & jobs | sed "s/  */ /g; s/ sleep 5 &//" ; kill %1 %2; wait' 
tm "%- marks previous job"    '\[1\]- .*\[2\]\+ ' 'sleep 5 & sleep 5 & jobs; kill %1 %2; wait'
t "wait for all jobs"         "all done"       'sleep 0.2 & sleep 0.3 & sleep 0.1 & wait; echo all done'
t "jobs empty after wait"     ""               'sleep 0.1 & wait; jobs'
tm "jobs -l shows pid+pgid"    'pgid=[0-9]+ +elapsed=[0-9:]+' 'sleep 5 & jobs -l; kill %1; wait'
tm "jobs -p prints pgid"       '^[0-9]+$'      'sleep 5 & jobs -p; kill %1; wait'
tm "jobs -r filters"           'Running'       'sleep 5 & jobs -r; kill %1; wait'
t "jobs -s empty if none"     ""               'sleep 5 & jobs -s; kill %1; wait'
tm "pipeline as one job"       '^\[1\]\+ +Running +sleep 5 \| cat &$' 'sleep 5 | cat & jobs; kill %1; wait'
tm "jobs -l lists both pids"   'pid [0-9]+ +running.*pid [0-9]+ +running' 'sleep 5 | cat & jobs -l; kill %1; wait'
t "kill whole pipeline job"   "143"            'sleep 5 | sleep 5 & kill %1; wait %1; echo $?'
tm "bad job spec"              'no such job'   'fg %9'
tm "kill bad job"              'kill: %7: no such job' 'kill %7'
tm "kill -l lists signals"     'SIGTERM'       'kill -l'
t "disown removes job"        ""               'sleep 0.2 & disown; jobs'
tm "%string job spec"          'Running'       'sleep 5 & sleep 6 & jobs %sleep; kill %1 %2; wait'
tm "bg job stdin is /dev/null" 'EOF'           'cat & wait; echo EOF'
t "bg builtin in background"  ""               'cd /tmp & wait; true'
t "bg job output works"       "bgout"          'echo bgout & wait'
t "bg job with redirect"      "x"              "echo x > $TMP/bg & wait; cat $TMP/bg"
t "jobs reports Done once"    '[1]   Done           true' 'true & sleep 0.2; jobs; jobs'

echo "== Stress =="
t "20 parallel jobs"          "20"             'sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & sleep 0.1 & echo 20; wait'
tm "job ids increase"          '\[20\]'        'sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & sleep 0.5 & jobs; wait'
t "no zombies after wait"     "0"              'sleep 0.1 & sleep 0.1 & wait; ps -o stat= --ppid $$ 2>/dev/null | grep -c Z; true'

echo
echo "Passed: $PASS   Failed: $FAIL"
[[ $FAIL -eq 0 ]]
