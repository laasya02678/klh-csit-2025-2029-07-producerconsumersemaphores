/*
 * parser.c - lexer + parser
 *
 * Grammar (informal):
 *   line     := pipeline ( (';' | '&') pipeline )* [ ';' | '&' ]
 *   pipeline := command ( '|' command )*
 *   command  := WORD+ with redirections  < f  > f  >> f  2> f  2>> f  2>&1
 *
 * The lexer performs quoting ('..' ".." \), $VAR / ${VAR} / $? / $$ / $!
 * expansion, ~ expansion and glob (*, ?, [..]) expansion.
 */
#include "shell.h"

#include <ctype.h>
#include <glob.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* ---------------------------- string buffer ------------------------- */
typedef struct {
    char *p;
    size_t len, cap;
} Buf;

static void buf_init(Buf *b) {
    b->cap = 32;
    b->len = 0;
    b->p = xmalloc(b->cap);
    b->p[0] = '\0';
}
static void buf_push(Buf *b, char c) {
    if (b->len + 2 > b->cap) {
        b->cap *= 2;
        b->p = xrealloc(b->p, b->cap);
    }
    b->p[b->len++] = c;
    b->p[b->len] = '\0';
}
static void buf_puts(Buf *b, const char *s) {
    while (*s) buf_push(b, *s++);
}

/* ------------------------------- tokens ----------------------------- */
enum {
    T_WORD, T_PIPE, T_IN, T_OUT, T_APPEND, T_ERR, T_ERRAPP, T_ERR2OUT,
    T_BG, T_SEMI
};

typedef struct {
    int type;
    char *text;
    size_t start, end; /* offsets in the original line */
} Token;

typedef struct {
    Token *t;
    int n, cap;
} TokVec;

static void tv_push(TokVec *v, int type, char *text, size_t s, size_t e) {
    if (v->n == v->cap) {
        v->cap = v->cap ? v->cap * 2 : 16;
        v->t = xrealloc(v->t, v->cap * sizeof(Token));
    }
    v->t[v->n++] = (Token){type, text, s, e};
}

static void tv_free(TokVec *v) {
    for (int i = 0; i < v->n; i++) free(v->t[i].text);
    free(v->t);
    v->t = NULL;
    v->n = v->cap = 0;
}

static void set_err(char *err, size_t n, const char *msg) {
    snprintf(err, n, "%s", msg);
}

/* Expand a variable starting at s[i] == '$'. Returns new index. */
static size_t expand_var(const char *s, size_t i, Buf *b) {
    char name[256];
    char c = s[i + 1];
    char tmp[32];
    if (c == '?') {
        snprintf(tmp, sizeof tmp, "%d", last_status);
        buf_puts(b, tmp);
        return i + 2;
    }
    if (c == '$') {
        snprintf(tmp, sizeof tmp, "%d", (int)getpid());
        buf_puts(b, tmp);
        return i + 2;
    }
    if (c == '!') {
        if (last_bg_pid > 0) {
            snprintf(tmp, sizeof tmp, "%d", (int)last_bg_pid);
            buf_puts(b, tmp);
        }
        return i + 2;
    }
    if (c == '{') {
        size_t j = i + 2, k = 0;
        while (s[j] && s[j] != '}' && k < sizeof name - 1) name[k++] = s[j++];
        if (s[j] != '}') {
            buf_push(b, '$');
            return i + 1;
        }
        name[k] = '\0';
        const char *v = getenv(name);
        if (v) buf_puts(b, v);
        return j + 1;
    }
    if (isalpha((unsigned char)c) || c == '_') {
        size_t j = i + 1, k = 0;
        while ((isalnum((unsigned char)s[j]) || s[j] == '_') && k < sizeof name - 1)
            name[k++] = s[j++];
        name[k] = '\0';
        const char *v = getenv(name);
        if (v) buf_puts(b, v);
        return j;
    }
    buf_push(b, '$');
    return i + 1;
}

static int is_op_char(char c) { return c && strchr("|&;<>", c) != NULL; }

static int lex(const char *line, size_t *pos, int one, TokVec *tv, char *err, size_t errlen) {
    size_t i = *pos;
    while (line[i]) {
        while (isspace((unsigned char)line[i])) i++;
        if (!line[i]) break;
        char c = line[i];
        size_t s = i;

        if (c == '#') break; /* comment */

        if (c == '|') {
            if (line[i + 1] == '|') {
                set_err(err, errlen, "operator '||' is not supported");
                return -1;
            }
            tv_push(tv, T_PIPE, NULL, s, ++i);
            continue;
        }
        if (c == '&') {
            if (line[i + 1] == '&') {
                set_err(err, errlen, "operator '&&' is not supported");
                return -1;
            }
            tv_push(tv, T_BG, NULL, s, ++i);
            if (one) { *pos = i; return 0; }
            continue;
        }
        if (c == ';') {
            tv_push(tv, T_SEMI, NULL, s, ++i);
            if (one) { *pos = i; return 0; }
            continue;
        }
        if (c == '<') {
            tv_push(tv, T_IN, NULL, s, ++i);
            continue;
        }
        if (c == '>') {
            if (line[i + 1] == '>') {
                i += 2;
                tv_push(tv, T_APPEND, NULL, s, i);
            } else {
                tv_push(tv, T_OUT, NULL, s, ++i);
            }
            continue;
        }
        if (c == '2' && line[i + 1] == '>') {
            if (line[i + 2] == '&' && line[i + 3] == '1') {
                i += 4;
                tv_push(tv, T_ERR2OUT, NULL, s, i);
            } else if (line[i + 2] == '>') {
                i += 3;
                tv_push(tv, T_ERRAPP, NULL, s, i);
            } else {
                i += 2;
                tv_push(tv, T_ERR, NULL, s, i);
            }
            continue;
        }

        /* ---- a word ---- */
        Buf b;
        buf_init(&b);
        int has_glob = 0, quoted = 0;
        while (line[i] && !isspace((unsigned char)line[i]) && !is_op_char(line[i])) {
            char ch = line[i];
            if (ch == '\'') {
                i++;
                while (line[i] && line[i] != '\'') buf_push(&b, line[i++]);
                if (!line[i]) {
                    free(b.p);
                    set_err(err, errlen, "unterminated single quote");
                    return -1;
                }
                i++;
                quoted = 1;
            } else if (ch == '"') {
                i++;
                while (line[i] && line[i] != '"') {
                    if (line[i] == '\\' && line[i + 1] && strchr("\"\\$`", line[i + 1])) {
                        buf_push(&b, line[i + 1]);
                        i += 2;
                    } else if (line[i] == '$') {
                        i = expand_var(line, i, &b);
                    } else {
                        buf_push(&b, line[i++]);
                    }
                }
                if (!line[i]) {
                    free(b.p);
                    set_err(err, errlen, "unterminated double quote");
                    return -1;
                }
                i++;
                quoted = 1;
            } else if (ch == '\\') {
                if (line[i + 1]) {
                    buf_push(&b, line[i + 1]);
                    i += 2;
                } else {
                    i++;
                }
                quoted = 1;
            } else if (ch == '$') {
                i = expand_var(line, i, &b);
            } else if (ch == '~' && i == s &&
                       (!line[i + 1] || line[i + 1] == '/' ||
                        isspace((unsigned char)line[i + 1]) || is_op_char(line[i + 1]))) {
                const char *home = getenv("HOME");
                buf_puts(&b, home ? home : "~");
                i++;
            } else {
                if (ch == '*' || ch == '?' || ch == '[') has_glob = 1;
                buf_push(&b, ch);
                i++;
            }
        }

        if (has_glob) {
            glob_t g;
            if (glob(b.p, 0, NULL, &g) == 0) {
                for (size_t k = 0; k < g.gl_pathc; k++)
                    tv_push(tv, T_WORD, xstrdup(g.gl_pathv[k]), s, i);
                globfree(&g);
                free(b.p);
                continue;
            }
            globfree(&g);
        }
        if (b.len == 0 && !quoted) { /* unquoted empty expansion vanishes */
            free(b.p);
            continue;
        }
        tv_push(tv, T_WORD, b.p, s, i);
    }
    *pos = i;
    return 0;
}

/* ------------------------------ parser ------------------------------ */
static void cmd_init(Command *c) { memset(c, 0, sizeof *c); }

static void cmd_add_arg(Command *c, char *word) {
    c->argv = xrealloc(c->argv, (c->argc + 2) * sizeof(char *));
    c->argv[c->argc++] = word;
    c->argv[c->argc] = NULL;
}

static void cmd_free(Command *c) {
    for (int i = 0; i < c->argc; i++) free(c->argv[i]);
    free(c->argv);
    free(c->in_file);
    free(c->out_file);
    free(c->err_file);
}

static void pipeline_free(Pipeline *p) {
    for (int i = 0; i < p->ncmds; i++) cmd_free(&p->cmds[i]);
    free(p->cmds);
    free(p->text);
}

void free_command_list(CommandList *cl) {
    for (int i = 0; i < cl->count; i++) pipeline_free(&cl->items[i]);
    free(cl->items);
    cl->items = NULL;
    cl->count = 0;
}

static char *dup_range(const char *s, size_t a, size_t b) {
    char *r = xmalloc(b - a + 1);
    memcpy(r, s + a, b - a);
    r[b - a] = '\0';
    return r;
}

static int parse_tokens(const char *line, TokVec *tvp, CommandList *out,
                        char *err, size_t errlen) {
    TokVec tv = *tvp;
    out->items = NULL;
    out->count = 0;

    Pipeline cur = {0};
    Command cmd;
    cmd_init(&cmd);
    int pending = -1;        /* pending redirection token type */
    size_t pstart = 0, pend = 0;
    int have_start = 0;
    int rc = 0;

#define FAIL(msg) do { set_err(err, errlen, msg); rc = -1; goto done; } while (0)

    for (int i = 0; i <= tv.n; i++) {
        int type = (i < tv.n) ? tv.t[i].type : -1; /* -1 = end of input */

        if (type == T_WORD) {
            if (!have_start) { pstart = tv.t[i].start; have_start = 1; }
            pend = tv.t[i].end;
            char *w = tv.t[i].text;
            tv.t[i].text = NULL; /* ownership moves */
            if (pending >= 0) {
                switch (pending) {
                case T_IN:     free(cmd.in_file);  cmd.in_file = w; break;
                case T_OUT:    free(cmd.out_file); cmd.out_file = w; cmd.out_append = 0; break;
                case T_APPEND: free(cmd.out_file); cmd.out_file = w; cmd.out_append = 1; break;
                case T_ERR:    free(cmd.err_file); cmd.err_file = w; cmd.err_append = 0; break;
                case T_ERRAPP: free(cmd.err_file); cmd.err_file = w; cmd.err_append = 1; break;
                }
                pending = -1;
            } else {
                cmd_add_arg(&cmd, w);
            }
            continue;
        }

        if (type == T_IN || type == T_OUT || type == T_APPEND ||
            type == T_ERR || type == T_ERRAPP || type == T_ERR2OUT) {
            if (pending >= 0) FAIL("syntax error: missing redirection target");
            if (!have_start) { pstart = tv.t[i].start; have_start = 1; }
            pend = tv.t[i].end;
            if (type == T_ERR2OUT) cmd.err_to_out = 1;
            else pending = type;
            continue;
        }

        /* from here: PIPE, SEMI, BG or end of input */
        if (pending >= 0) FAIL("syntax error: missing redirection target");

        if (type == T_PIPE) {
            if (cmd.argc == 0) FAIL("syntax error near '|'");
            cur.cmds = xrealloc(cur.cmds, (cur.ncmds + 1) * sizeof(Command));
            cur.cmds[cur.ncmds++] = cmd;
            cmd_init(&cmd);
            pend = tv.t[i].end;
            continue;
        }

        /* PIPE handled; now SEMI / BG / END terminate the pipeline */
        if (cmd.argc == 0 && (cmd.in_file || cmd.out_file || cmd.err_file || cmd.err_to_out))
            FAIL("syntax error: redirection without a command");
        if (cmd.argc == 0) {
            if (cur.ncmds > 0) FAIL("syntax error: missing command after '|'");
            if (type == -1) break;                       /* trailing blanks */
            if (type == T_SEMI || type == T_BG) FAIL(type == T_SEMI
                    ? "syntax error near ';'" : "syntax error near '&'");
        }
        cur.cmds = xrealloc(cur.cmds, (cur.ncmds + 1) * sizeof(Command));
        cur.cmds[cur.ncmds++] = cmd;
        cmd_init(&cmd);
        cur.background = (type == T_BG);
        /* text excludes the terminator */
        {
            size_t e = pend;
            while (e > pstart && isspace((unsigned char)line[e - 1])) e--;
            cur.text = dup_range(line, pstart, e);
        }
        out->items = xrealloc(out->items, (out->count + 1) * sizeof(Pipeline));
        out->items[out->count++] = cur;
        memset(&cur, 0, sizeof cur);
        have_start = 0;
    }

#undef FAIL
done:
    if (rc < 0) {
        cmd_free(&cmd);
        pipeline_free(&cur);
        free_command_list(out);
    }
    *tvp = tv;
    return rc;
}

/* Parse the whole line (used as a pure syntax check before executing). */
int parse_line(const char *line, CommandList *out, char *err, size_t errlen) {
    TokVec tv = {0};
    size_t pos = 0;
    out->items = NULL;
    out->count = 0;
    if (lex(line, &pos, 0, &tv, err, errlen) < 0) {
        tv_free(&tv);
        return -1;
    }
    int rc = parse_tokens(line, &tv, out, err, errlen);
    tv_free(&tv);
    return rc;
}

/*
 * Incremental parse: reads ONE pipeline starting at *pos. Variables are
 * expanded now, i.e. right before the pipeline runs, so "false; echo $?"
 * sees the status of the preceding command.
 * Returns 1 (pipeline stored in *out), 0 (end of input) or -1 (error).
 */
int parse_next(const char *line, size_t *pos, Pipeline *out, char *err, size_t errlen) {
    TokVec tv = {0};
    CommandList cl;
    if (lex(line, pos, 1, &tv, err, errlen) < 0) {
        tv_free(&tv);
        return -1;
    }
    int rc = parse_tokens(line, &tv, &cl, err, errlen);
    tv_free(&tv);
    if (rc < 0) return -1;
    if (cl.count == 0) {
        free_command_list(&cl);
        return 0;
    }
    *out = cl.items[0];
    free(cl.items);
    return 1;
}

void free_pipeline(Pipeline *p) { pipeline_free(p); }
