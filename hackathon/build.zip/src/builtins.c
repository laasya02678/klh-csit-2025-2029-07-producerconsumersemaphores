/*
 * builtins.c - builtin commands.
 *
 * Job control: jobs, fg, bg, kill, wait, disown
 * Shell:       cd, pwd, exit, export, unset, history, help
 */
#include "shell.h"

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

extern char **environ;

typedef int (*builtin_fn)(int, char **);
typedef struct {
    const char *name;
    builtin_fn fn;
} Builtin;

/* ------------------------------ signals ----------------------------- */
static const struct { const char *name; int num; } sigtab[] = {
    {"HUP", SIGHUP},   {"INT", SIGINT},   {"QUIT", SIGQUIT}, {"KILL", SIGKILL},
    {"USR1", SIGUSR1}, {"USR2", SIGUSR2}, {"PIPE", SIGPIPE}, {"ALRM", SIGALRM},
    {"TERM", SIGTERM}, {"CHLD", SIGCHLD}, {"CONT", SIGCONT}, {"STOP", SIGSTOP},
    {"TSTP", SIGTSTP}, {"TTIN", SIGTTIN}, {"TTOU", SIGTTOU},
};
#define NSIG_TAB ((int)(sizeof sigtab / sizeof sigtab[0]))

static int parse_signal(const char *s) {
    if (isdigit((unsigned char)*s)) {
        char *end;
        long v = strtol(s, &end, 10);
        return (*end == '\0' && v > 0 && v < 65) ? (int)v : -1;
    }
    if (!strncasecmp(s, "SIG", 3)) s += 3;
    for (int i = 0; i < NSIG_TAB; i++)
        if (!strcasecmp(s, sigtab[i].name)) return sigtab[i].num;
    return -1;
}

static int parse_int(const char *s, long *out) {
    char *end;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || *end || end == s) return -1;
    *out = v;
    return 0;
}

/* ----------------------------- job control -------------------------- */
static int bi_jobs(int argc, char **argv) {
    int longfmt = 0, pidonly = 0, only_running = 0, only_stopped = 0;
    int i = 1;
    for (; i < argc && argv[i][0] == '-' && argv[i][1]; i++) {
        for (const char *f = argv[i] + 1; *f; f++) {
            switch (*f) {
            case 'l': longfmt = 1; break;
            case 'p': pidonly = 1; break;
            case 'r': only_running = 1; break;
            case 's': only_stopped = 1; break;
            default:
                fprintf(stderr, "jobs: -%c: invalid option\nusage: jobs [-lprs] [jobspec...]\n", *f);
                return 2;
            }
        }
    }
    jobs_reap();
    int status = 0;
    if (i < argc) {
        for (; i < argc; i++) {
            Job *j = job_from_spec(argv[i]);
            if (!j) {
                fprintf(stderr, "jobs: %s: no such job\n", argv[i]);
                status = 1;
                continue;
            }
            job_print(j, longfmt, pidonly);
        }
    } else {
        for (Job *j = job_first(); j; j = j->next) {
            if (only_running && j->state != JOB_RUNNING) continue;
            if (only_stopped && j->state != JOB_STOPPED) continue;
            job_print(j, longfmt, pidonly);
        }
    }
    /* finished jobs have now been reported: drop them */
    Job *j = job_first();
    while (j) {
        Job *next = j->next;
        if (j->state == JOB_DONE && j->background) job_remove(j);
        j = next;
    }
    return status;
}

static int bi_fg(int argc, char **argv) {
    Job *j = job_from_spec(argc > 1 ? argv[1] : NULL);
    if (!j) {
        if (argc > 1) fprintf(stderr, "fg: %s: no such job\n", argv[1]);
        else fprintf(stderr, "fg: no current job\n");
        return 1;
    }
    printf("%s\n", j->cmd);
    fflush(stdout);
    return job_run_foreground(j, 1);
}

static int bi_bg(int argc, char **argv) {
    Job *j = job_from_spec(argc > 1 ? argv[1] : NULL);
    if (!j) {
        if (argc > 1) fprintf(stderr, "bg: %s: no such job\n", argv[1]);
        else fprintf(stderr, "bg: no current job\n");
        return 1;
    }
    if (j->state != JOB_STOPPED) {
        fprintf(stderr, "bg: job %d already running\n", j->id);
        return 1;
    }
    j->background = 1;
    job_continue(j);
    printf("[%d]%c %s &\n", j->id, (j == job_current()) ? '+' : ' ', j->cmd);
    return 0;
}

static int bi_kill(int argc, char **argv) {
    int sig = SIGTERM, i = 1;
    if (argc < 2) {
        fprintf(stderr, "usage: kill [-s SIGNAL | -SIGNAL] pid|%%job ...\n       kill -l\n");
        return 2;
    }
    if (!strcmp(argv[1], "-l")) {
        for (int k = 0; k < NSIG_TAB; k++)
            printf("%2d) SIG%-5s%s", sigtab[k].num, sigtab[k].name, (k % 5 == 4) ? "\n" : "  ");
        printf("\n");
        return 0;
    }
    if (!strcmp(argv[1], "-s") && argc > 2) {
        sig = parse_signal(argv[2]);
        i = 3;
    } else if (argv[1][0] == '-' && argv[1][1]) {
        sig = parse_signal(argv[1] + 1);
        i = 2;
    }
    if (sig < 0) {
        fprintf(stderr, "kill: invalid signal specification\n");
        return 2;
    }
    if (i >= argc) {
        fprintf(stderr, "kill: no target given\n");
        return 2;
    }
    int status = 0;
    for (; i < argc; i++) {
        if (argv[i][0] == '%') {
            Job *j = job_from_spec(argv[i]);
            if (!j) {
                fprintf(stderr, "kill: %s: no such job\n", argv[i]);
                status = 1;
                continue;
            }
            if (job_signal(j, sig) < 0) {
                fprintf(stderr, "kill: %s: %s\n", argv[i], strerror(errno));
                status = 1;
                continue;
            }
            /* a stopped job cannot act on SIGTERM etc. until it is resumed */
            if (j->state == JOB_STOPPED &&
                (sig == SIGTERM || sig == SIGHUP || sig == SIGINT || sig == SIGQUIT))
                job_signal(j, SIGCONT);
        } else {
            long pid;
            if (parse_int(argv[i], &pid) < 0) {
                fprintf(stderr, "kill: %s: arguments must be job specs or process ids\n", argv[i]);
                status = 1;
                continue;
            }
            if (kill((pid_t)pid, sig) < 0) {
                fprintf(stderr, "kill: (%ld): %s\n", pid, strerror(errno));
                status = 1;
            }
        }
    }
    return status;
}

static int wait_one(Job *j) {
    if (job_wait(j, 1) < 0) {
        got_sigint = 0;
        return 130;
    }
    int st = j->exit_status;
    if (j->state == JOB_DONE) job_remove(j);
    return st;
}

static int bi_wait(int argc, char **argv) {
    if (argc == 1) {
        for (;;) {
            Job *target = NULL;
            for (Job *j = job_first(); j; j = j->next)
                if (j->state == JOB_RUNNING) { target = j; break; }
            if (!target) break;
            if (job_wait(target, 1) < 0) {
                got_sigint = 0;
                return 130;
            }
        }
        /* everything we waited for is finished: consume the Done entries */
        Job *j = job_first();
        while (j) {
            Job *next = j->next;
            if (j->state == JOB_DONE && j->background) job_remove(j);
            j = next;
        }
        return 0;
    }
    int status = 0;
    for (int i = 1; i < argc; i++) {
        Job *j = NULL;
        if (argv[i][0] == '%') {
            j = job_from_spec(argv[i]);
        } else {
            long v;
            if (parse_int(argv[i], &v) == 0) {
                j = job_by_pid((pid_t)v);
                if (!j) j = job_by_id((int)v);
            }
        }
        if (!j) {
            fprintf(stderr, "wait: %s: not a child of this shell\n", argv[i]);
            status = 127;
            continue;
        }
        status = wait_one(j);
        if (status == 130) return 130;
    }
    return status;
}

static int bi_disown(int argc, char **argv) {
    if (argc > 1 && !strcmp(argv[1], "-a")) {
        Job *j = job_first();
        while (j) {
            Job *n = j->next;
            job_remove(j);
            j = n;
        }
        return 0;
    }
    Job *j = job_from_spec(argc > 1 ? argv[1] : NULL);
    if (!j) {
        fprintf(stderr, "disown: %s: no such job\n", argc > 1 ? argv[1] : "current");
        return 1;
    }
    job_remove(j);
    return 0;
}

/* ------------------------------- shell ------------------------------ */
static int bi_cd(int argc, char **argv) {
    const char *target;
    char old[PATH_MAX];
    int print = 0;
    if (argc > 2) {
        fprintf(stderr, "cd: too many arguments\n");
        return 1;
    }
    if (argc == 1) {
        target = getenv("HOME");
        if (!target) {
            fprintf(stderr, "cd: HOME not set\n");
            return 1;
        }
    } else if (!strcmp(argv[1], "-")) {
        target = getenv("OLDPWD");
        if (!target) {
            fprintf(stderr, "cd: OLDPWD not set\n");
            return 1;
        }
        print = 1;
    } else {
        target = argv[1];
    }
    if (!getcwd(old, sizeof old)) old[0] = '\0';
    if (chdir(target) < 0) {
        fprintf(stderr, "cd: %s: %s\n", target, strerror(errno));
        return 1;
    }
    char now[PATH_MAX];
    if (old[0]) setenv("OLDPWD", old, 1);
    if (getcwd(now, sizeof now)) setenv("PWD", now, 1);
    if (print) printf("%s\n", now);
    return 0;
}

static int bi_pwd(int argc, char **argv) {
    (void)argc; (void)argv;
    char buf[PATH_MAX];
    if (!getcwd(buf, sizeof buf)) {
        perror("pwd");
        return 1;
    }
    printf("%s\n", buf);
    return 0;
}

int shell_should_exit = 0;
int shell_exit_code = 0;
int exit_warned = 0;

static int bi_exit(int argc, char **argv) {
    if (job_count(JOB_STOPPED) > 0 && !exit_warned && shell_interactive) {
        fprintf(stderr, "There are stopped jobs. (type exit again to force)\n");
        exit_warned = 1;
        return 1;
    }
    int code = last_status;
    if (argc > 1) {
        long v;
        if (parse_int(argv[1], &v) < 0) {
            fprintf(stderr, "exit: %s: numeric argument required\n", argv[1]);
            code = 2;
        } else {
            code = (int)(v & 0xff);
        }
    }
    shell_should_exit = 1;
    shell_exit_code = code;
    return code;
}

static int bi_export(int argc, char **argv) {
    if (argc == 1) {
        for (char **e = environ; *e; e++) printf("export %s\n", *e);
        return 0;
    }
    int status = 0;
    for (int i = 1; i < argc; i++) {
        char *eq = strchr(argv[i], '=');
        if (!eq) continue;
        *eq = '\0';
        if (!*argv[i] || setenv(argv[i], eq + 1, 1) < 0) {
            fprintf(stderr, "export: `%s': not a valid identifier\n", argv[i]);
            status = 1;
        }
        *eq = '=';
    }
    return status;
}

static int bi_unset(int argc, char **argv) {
    for (int i = 1; i < argc; i++) unsetenv(argv[i]);
    return 0;
}

static int bi_history(int argc, char **argv) {
    int n = history_count(), from = 1;
    if (argc > 1) {
        long v;
        if (parse_int(argv[1], &v) < 0 || v < 0) {
            fprintf(stderr, "history: %s: numeric argument required\n", argv[1]);
            return 1;
        }
        if (v < n) from = n - (int)v + 1;
    }
    for (int i = from; i <= n; i++) printf("%5d  %s\n", i, history_get(i));
    return 0;
}

static int bi_help(int argc, char **argv) {
    (void)argc; (void)argv;
    puts("mysh - Mini Linux Shell with Background Job Management\n"
         "\n"
         "Syntax:\n"
         "  cmd args            run a command         cmd &        run in background\n"
         "  a | b | c           pipeline              a ; b        sequence\n"
         "  < f  > f  >> f      redirect stdin/stdout 2> f  2>&1   redirect stderr\n"
         "  $VAR ${VAR} $? $! $$  ~  * ? [..]  'quote' \"quote\"  \\escape  # comment\n"
         "  !!   !N             repeat last / N-th history line\n"
         "\n"
         "Job control (Ctrl+Z stops the foreground job, Ctrl+C interrupts it):\n"
         "  jobs [-lprs] [%n]   list jobs (-l pids+elapsed, -p pgids, -r running, -s stopped)\n"
         "  fg [%n]             bring a job to the foreground\n"
         "  bg [%n]             resume a stopped job in the background\n"
         "  kill [-SIG] %n|pid  send a signal (default TERM); kill -l lists signals\n"
         "  wait [%n|pid ...]   wait for background jobs, returns their exit status\n"
         "  disown [-a|%n]      forget a job (it will not be signalled at exit)\n"
         "\n"
         "Job specs: %n  %%  %+  %-  %string  %?substring\n"
         "\n"
         "Other: cd [dir|-]  pwd  export [N=V]  unset N  history [n]  exit [n]  help");
    return 0;
}

static const Builtin table[] = {
    {"jobs", bi_jobs},     {"fg", bi_fg},       {"bg", bi_bg},
    {"kill", bi_kill},     {"wait", bi_wait},   {"disown", bi_disown},
    {"cd", bi_cd},         {"pwd", bi_pwd},     {"exit", bi_exit},
    {"export", bi_export}, {"unset", bi_unset}, {"history", bi_history},
    {"help", bi_help},
};
#define NBUILTINS ((int)(sizeof table / sizeof table[0]))

int is_builtin(const char *name) {
    for (int i = 0; i < NBUILTINS; i++)
        if (!strcmp(name, table[i].name)) return 1;
    return 0;
}

int run_builtin(int argc, char **argv) {
    for (int i = 0; i < NBUILTINS; i++)
        if (!strcmp(argv[0], table[i].name)) return table[i].fn(argc, argv);
    return 127;
}
