/* util.c - allocation helpers, time formatting and command history */
#include "shell.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void *xmalloc(size_t n) {
    void *p = malloc(n ? n : 1);
    if (!p) {
        fputs("mysh: out of memory\n", stderr);
        exit(1);
    }
    return p;
}

void *xrealloc(void *p, size_t n) {
    p = realloc(p, n ? n : 1);
    if (!p) {
        fputs("mysh: out of memory\n", stderr);
        exit(1);
    }
    return p;
}

char *xstrdup(const char *s) {
    size_t n = strlen(s) + 1;
    char *p = xmalloc(n);
    memcpy(p, s, n);
    return p;
}

void fmt_elapsed(time_t secs, char *buf, size_t n) {
    if (secs < 0) secs = 0;
    snprintf(buf, n, "%02ld:%02ld:%02ld", (long)(secs / 3600),
             (long)((secs / 60) % 60), (long)(secs % 60));
}

/* ------------------------------ history ----------------------------- */
#define HIST_MAX 1000
static char *hist[HIST_MAX];
static int hist_n = 0;

void history_add(const char *line) {
    if (!*line) return;
    if (hist_n && strcmp(hist[hist_n - 1], line) == 0) return;
    if (hist_n == HIST_MAX) {
        free(hist[0]);
        memmove(hist, hist + 1, (HIST_MAX - 1) * sizeof(char *));
        hist_n--;
    }
    hist[hist_n++] = xstrdup(line);
}

int history_count(void) { return hist_n; }

const char *history_get(int idx) {
    if (idx < 1 || idx > hist_n) return NULL;
    return hist[idx - 1];
}

static void history_path(char *buf, size_t n) {
    const char *home = getenv("HOME");
    snprintf(buf, n, "%s/.mysh_history", home ? home : ".");
}

void history_load(void) {
    char path[4096];
    history_path(path, sizeof path);
    FILE *f = fopen(path, "r");
    if (!f) return;
    char *line = NULL;
    size_t cap = 0;
    ssize_t r;
    while ((r = getline(&line, &cap, f)) > 0) {
        if (line[r - 1] == '\n') line[r - 1] = '\0';
        history_add(line);
    }
    free(line);
    fclose(f);
}

void history_save(void) {
    char path[4096];
    history_path(path, sizeof path);
    FILE *f = fopen(path, "w");
    if (!f) return;
    for (int i = 0; i < hist_n; i++) fprintf(f, "%s\n", hist[i]);
    fclose(f);
}
