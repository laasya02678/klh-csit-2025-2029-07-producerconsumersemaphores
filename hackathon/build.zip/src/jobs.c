/*
 * jobs.c - the job table.
 *
 * A Job is one pipeline (one or more processes sharing a process group).
 * Each Proc records whether it has exited or is stopped; the Job state is
 * derived from its processes:
 *
 *      all processes done        -> JOB_DONE
 *      some process running      -> JOB_RUNNING
 *      otherwise (all stopped)   -> JOB_STOPPED
 *
 * Status changes arrive through waitpid(); nothing here runs inside a
 * signal handler, so the table needs no locking.
 */
#include "shell.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static Job *head = NULL;
static unsigned long touch_ctr = 0;

Job *job_first(void) { return head; }

Job *job_create(pid_t pgid, const char *cmd, const pid_t *pids, int n, int background) {
    Job *j = xmalloc(sizeof *j);
    memset(j, 0, sizeof *j);
    int maxid = 0;
    Job *tail = NULL;
    for (Job *q = head; q; q = q->next) {
        if (q->id > maxid) maxid = q->id;
        tail = q;
    }
    j->id = maxid + 1;
    j->pgid = pgid;
    j->cmd = xstrdup(cmd);
    j->nprocs = n;
    j->procs = xmalloc(n * sizeof(Proc));
    memset(j->procs, 0, n * sizeof(Proc));
    for (int i = 0; i < n; i++) j->procs[i].pid = pids[i];
    j->state = JOB_RUNNING;
    j->background = background;
    j->started = time(NULL);
    j->touch = ++touch_ctr;
    if (tail) tail->next = j;
    else head = j;
    return j;
}

void job_remove(Job *j) {
    Job **pp = &head;
    while (*pp && *pp != j) pp = &(*pp)->next;
    if (!*pp) return;
    *pp = j->next;
    free(j->cmd);
    free(j->procs);
    free(j);
}

Job *job_by_id(int id) {
    for (Job *j = head; j; j = j->next)
        if (j->id == id) return j;
    return NULL;
}

Job *job_by_pid(pid_t pid) {
    for (Job *j = head; j; j = j->next)
        for (int i = 0; i < j->nprocs; i++)
            if (j->procs[i].pid == pid) return j;
    return NULL;
}

/* ---------------- current (%+) and previous (%-) job ---------------- */
static long score(const Job *j) {
    return (long)j->touch + (j->state == JOB_STOPPED ? 1000000000L : 0);
}

Job *job_current(void) {
    Job *best = NULL;
    for (Job *j = head; j; j = j->next) {
        if (j->state == JOB_DONE) continue;
        if (!best || score(j) > score(best)) best = j;
    }
    return best;
}

Job *job_previous(void) {
    Job *cur = job_current(), *best = NULL;
    for (Job *j = head; j; j = j->next) {
        if (j == cur || j->state == JOB_DONE) continue;
        if (!best || score(j) > score(best)) best = j;
    }
    return best;
}

Job *job_from_spec(const char *spec) {
    if (!spec || !*spec || !strcmp(spec, "%%") || !strcmp(spec, "%+"))
        return job_current();
    if (!strcmp(spec, "%-")) return job_previous();

    const char *s = spec;
    int percent = (*s == '%');
    if (percent) s++;
    if (isdigit((unsigned char)*s)) {
        char *end;
        long id = strtol(s, &end, 10);
        if (*end == '\0') return job_by_id((int)id);
        return NULL;
    }
    if (!percent || !*s) return NULL;
    if (*s == '?') { /* %?substring */
        s++;
        for (Job *j = head; j; j = j->next)
            if (strstr(j->cmd, s)) return j;
        return NULL;
    }
    for (Job *j = head; j; j = j->next) /* %prefix */
        if (strncmp(j->cmd, s, strlen(s)) == 0) return j;
    return NULL;
}

int job_count(JobState st) {
    int n = 0;
    for (Job *j = head; j; j = j->next)
        if (j->state == st) n++;
    return n;
}

/* ------------------------- state tracking --------------------------- */
void job_refresh(Job *j) {
    int alldone = 1, anyrunning = 0;
    for (int i = 0; i < j->nprocs; i++) {
        if (!j->procs[i].done) {
            alldone = 0;
            if (!j->procs[i].stopped) anyrunning = 1;
        }
    }
    JobState old = j->state, ns;
    if (alldone) ns = JOB_DONE;
    else if (anyrunning) ns = JOB_RUNNING;
    else ns = JOB_STOPPED;
    j->state = ns;

    if (ns == JOB_DONE && old != JOB_DONE) {
        int st = j->procs[j->nprocs - 1].status;
        if (WIFEXITED(st)) {
            j->exit_status = WEXITSTATUS(st);
            j->term_sig = 0;
        } else if (WIFSIGNALED(st)) {
            j->term_sig = WTERMSIG(st);
            j->exit_status = 128 + j->term_sig;
        }
    }
    if (ns != old && ns != JOB_DONE) {
        j->notified = 0;
        j->touch = ++touch_ctr;
    }
}

static void mark_status(pid_t pid, int st) {
    Job *j = job_by_pid(pid);
    if (!j) return;
    for (int i = 0; i < j->nprocs; i++) {
        Proc *p = &j->procs[i];
        if (p->pid != pid) continue;
        if (WIFSTOPPED(st)) {
            p->stopped = 1;
        } else if (WIFCONTINUED(st)) {
            p->stopped = 0;
        } else {
            p->done = 1;
            p->stopped = 0;
            p->status = st;
        }
        break;
    }
    job_refresh(j);
}

void jobs_reap(void) {
    int st;
    pid_t pid;
    for (;;) {
        pid = waitpid(-1, &st, WNOHANG | WUNTRACED | WCONTINUED);
        if (pid > 0) mark_status(pid, st);
        else if (pid < 0 && errno == EINTR) continue;
        else break;
    }
}

int job_wait(Job *j, int interruptible) {
    while (j->state == JOB_RUNNING) {
        int st;
        pid_t pid = waitpid(-1, &st, WUNTRACED);
        if (pid > 0) {
            mark_status(pid, st);
        } else if (pid < 0) {
            if (errno == EINTR) {
                if (interruptible && got_sigint) return -1;
                continue;
            }
            /* ECHILD: children vanished (e.g. reaped elsewhere) */
            for (int i = 0; i < j->nprocs; i++) j->procs[i].done = 1;
            job_refresh(j);
            break;
        }
    }
    return 0;
}

int job_signal(Job *j, int sig) {
    if (shell_interactive) return kill(-j->pgid, sig);
    int rc = 0;
    for (int i = 0; i < j->nprocs; i++)
        if (!j->procs[i].done && kill(j->procs[i].pid, sig) < 0) rc = -1;
    return rc;
}

void job_continue(Job *j) {
    job_signal(j, SIGCONT);
    for (int i = 0; i < j->nprocs; i++) j->procs[i].stopped = 0;
    job_refresh(j);
    j->notified = 0;
    j->touch = ++touch_ctr;
}

void jobs_hup_all(void) {
    for (Job *j = head; j; j = j->next) {
        if (j->state == JOB_DONE) continue;
        job_signal(j, SIGHUP);
        if (j->state == JOB_STOPPED) job_signal(j, SIGCONT);
    }
}

/* ----------------------------- printing ----------------------------- */
static void state_desc(const Job *j, char *buf, size_t n) {
    switch (j->state) {
    case JOB_RUNNING: snprintf(buf, n, "Running"); break;
    case JOB_STOPPED: snprintf(buf, n, "Stopped"); break;
    case JOB_DONE:
        if (j->term_sig) snprintf(buf, n, "%s", strsignal(j->term_sig));
        else if (j->exit_status) snprintf(buf, n, "Exit %d", j->exit_status);
        else snprintf(buf, n, "Done");
        break;
    }
}

void job_print(Job *j, int long_format, int pid_only) {
    if (pid_only) {
        printf("%d\n", (int)j->pgid);
        return;
    }
    Job *cur = job_current(), *prev = job_previous();
    char mark = (j == cur) ? '+' : (j == prev) ? '-' : ' ';
    char st[64];
    state_desc(j, st, sizeof st);
    const char *amp = (j->state == JOB_RUNNING && j->background) ? " &" : "";
    printf("[%d]%c  %-14s %s%s\n", j->id, mark, st, j->cmd, amp);
    if (long_format) {
        char el[16];
        fmt_elapsed(time(NULL) - j->started, el, sizeof el);
        printf("       pgid=%d  elapsed=%s\n", (int)j->pgid, el);
        for (int i = 0; i < j->nprocs; i++) {
            const Proc *p = &j->procs[i];
            char ps[64];
            if (p->done) {
                if (WIFSIGNALED(p->status))
                    snprintf(ps, sizeof ps, "killed by %s", strsignal(WTERMSIG(p->status)));
                else
                    snprintf(ps, sizeof ps, "exited(%d)", WEXITSTATUS(p->status));
            } else if (p->stopped) {
                snprintf(ps, sizeof ps, "stopped");
            } else {
                snprintf(ps, sizeof ps, "running");
            }
            printf("       |- pid %d  %s\n", (int)p->pid, ps);
        }
    }
}

/* ------------------------- async notification ----------------------- */
int jobs_pending_notice(void) {
    for (Job *j = head; j; j = j->next) {
        if (!j->background) continue;
        if (j->state == JOB_DONE) return 1;
        if (j->state == JOB_STOPPED && !j->notified) return 1;
    }
    return 0;
}

int jobs_notify(int verbose) {
    int n = 0;
    Job *j = head;
    while (j) {
        Job *next = j->next;
        if (j->background) {
            if (j->state == JOB_DONE) {
                if (verbose) { job_print(j, 0, 0); n++; }
                job_remove(j);
            } else if (j->state == JOB_STOPPED && !j->notified) {
                if (verbose) { job_print(j, 0, 0); n++; }
                j->notified = 1;
            }
        }
        j = next;
    }
    return n;
}
