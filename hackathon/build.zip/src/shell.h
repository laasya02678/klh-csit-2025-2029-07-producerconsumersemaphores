/*
 * mysh - Mini Linux Shell with Background Job Management
 * Shared declarations for all modules.
 */
#ifndef MYSH_H
#define MYSH_H

#include <signal.h>
#include <stddef.h>
#include <sys/types.h>
#include <termios.h>
#include <time.h>

/* ------------------------------------------------------------------ */
/* util.c                                                             */
/* ------------------------------------------------------------------ */
void *xmalloc(size_t n);
void *xrealloc(void *p, size_t n);
char *xstrdup(const char *s);
void fmt_elapsed(time_t secs, char *buf, size_t n);

void history_add(const char *line);
int history_count(void);
const char *history_get(int one_based_index);
void history_load(void);
void history_save(void);

/* ------------------------------------------------------------------ */
/* parser.c : tokenizer + parser                                      */
/* ------------------------------------------------------------------ */
typedef struct {
    char **argv;        /* NULL-terminated */
    int argc;
    char *in_file;      /* < file   */
    char *out_file;     /* > file or >> file */
    char *err_file;     /* 2> file or 2>> file */
    int out_append;
    int err_append;
    int err_to_out;     /* 2>&1 */
} Command;

typedef struct {
    Command *cmds;      /* cmd1 | cmd2 | ... */
    int ncmds;
    int background;     /* terminated by '&' */
    char *text;         /* original text (used for the job table) */
} Pipeline;

typedef struct {
    Pipeline *items;    /* sequence separated by ';' or '&' */
    int count;
} CommandList;

/* Returns 0 on success, -1 on syntax error (message stored in err). */
int parse_line(const char *line, CommandList *out, char *err, size_t errlen);
void free_command_list(CommandList *cl);
/* Incremental: 1 = got a pipeline, 0 = end of input, -1 = syntax error. */
int parse_next(const char *line, size_t *pos, Pipeline *out, char *err, size_t errlen);
void free_pipeline(Pipeline *p);

/* ------------------------------------------------------------------ */
/* Global shell state (defined in main.c)                             */
/* ------------------------------------------------------------------ */
extern int shell_interactive;
extern int last_status;                 /* $?  */
extern pid_t last_bg_pid;               /* $!  */
extern pid_t shell_pgid;
extern struct termios shell_tmodes;
extern volatile sig_atomic_t got_sigint;
extern int shell_should_exit;
extern int shell_exit_code;
extern int exit_warned;

/* ------------------------------------------------------------------ */
/* jobs.c : job table                                                 */
/* ------------------------------------------------------------------ */
typedef enum { JOB_RUNNING, JOB_STOPPED, JOB_DONE } JobState;

typedef struct {
    pid_t pid;
    int status;         /* raw waitpid status once done */
    int done;
    int stopped;
} Proc;

typedef struct Job {
    int id;                     /* [n] */
    pid_t pgid;
    char *cmd;
    Proc *procs;
    int nprocs;
    JobState state;
    int exit_status;            /* valid when DONE */
    int term_sig;               /* signal that killed it, or 0 */
    int background;             /* currently a background job? */
    int notified;               /* user already told about Done/Stopped */
    time_t started;
    unsigned long touch;        /* recency, for %+ and %- */
    struct termios tmodes;      /* terminal modes saved when stopped */
    int has_tmodes;
    struct Job *next;
} Job;

Job *job_create(pid_t pgid, const char *cmd, const pid_t *pids, int n, int background);
void job_remove(Job *j);
Job *job_first(void);
Job *job_by_id(int id);
Job *job_by_pid(pid_t pid);
Job *job_from_spec(const char *spec);   /* %n %% %+ %- %str %?str n */
Job *job_current(void);
Job *job_previous(void);
int job_count(JobState st);
void job_refresh(Job *j);
void jobs_reap(void);                   /* non-blocking, updates the table */
int job_wait(Job *j, int interruptible);/* 0 ok, -1 interrupted */
int job_signal(Job *j, int sig);
void job_continue(Job *j);
void job_print(Job *j, int long_format, int pid_only);
int jobs_pending_notice(void);
int jobs_notify(int verbose);           /* returns number of notices printed */
void jobs_hup_all(void);

/* ------------------------------------------------------------------ */
/* executor.c                                                         */
/* ------------------------------------------------------------------ */
int run_pipeline(const Pipeline *p);
int job_run_foreground(Job *j, int send_cont);

/* ------------------------------------------------------------------ */
/* builtins.c                                                         */
/* ------------------------------------------------------------------ */
int is_builtin(const char *name);
int run_builtin(int argc, char **argv);

#endif
