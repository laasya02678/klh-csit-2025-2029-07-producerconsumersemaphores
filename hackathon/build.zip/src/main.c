/*
 * main.c - shell initialisation and the read-eval-print loop.
 *
 * Usage:  mysh                interactive shell
 *         mysh -c "command"   run one command line
 *         mysh script.sh      run commands from a file
 */
#include "shell.h"

#include <ctype.h>
#include <errno.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

int shell_interactive = 0;
int last_status = 0;
pid_t last_bg_pid = 0;
pid_t shell_pgid = 0;
struct termios shell_tmodes;
volatile sig_atomic_t got_sigint = 0;

static void sigint_handler(int sig) {
    (void)sig;
    got_sigint = 1;
}

/* ----------------------------- start-up ----------------------------- */
static void shell_init(void) {
    shell_interactive = isatty(STDIN_FILENO);
    if (!shell_interactive) return;

    /* Loop until we are in the foreground process group. */
    while (tcgetpgrp(STDIN_FILENO) != (shell_pgid = getpgrp()))
        kill(-shell_pgid, SIGTTIN);

    /* The shell itself must not be stopped or killed by job-control keys. */
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sigemptyset(&sa.sa_mask);
    sa.sa_handler = sigint_handler;   /* no SA_RESTART: lets wait() be interrupted */
    sigaction(SIGINT, &sa, NULL);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTTOU, SIG_IGN);

    /* Own process group, own the terminal. */
    shell_pgid = getpid();
    if (setpgid(shell_pgid, shell_pgid) < 0 && errno != EPERM) {
        perror("mysh: setpgid");
        exit(1);
    }
    tcsetpgrp(STDIN_FILENO, shell_pgid);
    tcgetattr(STDIN_FILENO, &shell_tmodes);

    setvbuf(stdin, NULL, _IONBF, 0); /* we poll() on fd 0 */
    history_load();
}

static void shell_cleanup(void) {
    if (shell_interactive) {
        jobs_hup_all();
        history_save();
    }
}

/* ------------------------------ prompt ------------------------------ */
static void print_prompt(void) {
    const char *custom = getenv("MYSH_PROMPT");
    if (custom) {
        fputs(custom, stdout);
    } else {
        int run = job_count(JOB_RUNNING), stp = job_count(JOB_STOPPED);
        if (run || stp) {
            printf("mysh[");
            if (run) printf("%d running", run);
            if (run && stp) printf(", ");
            if (stp) printf("%d stopped", stp);
            printf("]$ ");
        } else {
            printf("mysh$ ");
        }
    }
    fflush(stdout);
}

/* ------------------------------ input ------------------------------- */
static void chomp(char *s, ssize_t n) {
    if (n > 0 && s[n - 1] == '\n') s[n - 1] = '\0';
}

/*
 * Reads one line. While waiting at the prompt we poll() with a timeout so
 * that background jobs that finish (or stop) are reported immediately,
 * not only the next time the user presses Enter.
 */
static char *read_line(void) {
    char *line = NULL;
    size_t cap = 0;

    if (!shell_interactive) {
        ssize_t n = getline(&line, &cap, stdin);
        if (n < 0) {
            free(line);
            return NULL;
        }
        chomp(line, n);
        return line;
    }

    print_prompt();
    for (;;) {
        struct pollfd pfd = {STDIN_FILENO, POLLIN, 0};
        int r = poll(&pfd, 1, 200);
        if (r < 0) {
            if (errno == EINTR) {
                if (got_sigint) {
                    got_sigint = 0;
                    fputc('\n', stdout);
                    print_prompt();
                }
                continue;
            }
            return NULL;
        }
        if (r == 0) {
            jobs_reap();
            if (jobs_pending_notice()) {
                fputc('\n', stdout);
                jobs_notify(1);
                print_prompt();
            }
            continue;
        }
        ssize_t n = getline(&line, &cap, stdin);
        if (n < 0) {
            if (errno == EINTR) {
                clearerr(stdin);
                continue;
            }
            free(line);
            return NULL;
        }
        chomp(line, n);
        return line;
    }
}

/* ---------------------------- evaluation ---------------------------- */
static void process_line(const char *line) {
    CommandList check;
    char err[256];

    /* 1. syntax-check the whole line so a bad line runs nothing */
    if (parse_line(line, &check, err, sizeof err) < 0) {
        fprintf(stderr, "mysh: %s\n", err);
        last_status = 2;
        return;
    }
    free_command_list(&check);

    /* 2. expand + run one pipeline at a time */
    size_t pos = 0;
    while (!shell_should_exit) {
        Pipeline p;
        int r = parse_next(line, &pos, &p, err, sizeof err);
        if (r < 0) {
            fprintf(stderr, "mysh: %s\n", err);
            last_status = 2;
            return;
        }
        if (r == 0) break;
        last_status = run_pipeline(&p);
        free_pipeline(&p);
    }
}

/* Handles "!!" and "!N". Returns a malloc'd replacement or NULL. */
static char *history_expand(const char *line) {
    const char *p = line;
    while (isspace((unsigned char)*p)) p++;
    if (p[0] != '!' || !p[1]) return NULL;
    const char *h = NULL;
    if (!strcmp(p, "!!")) {
        h = history_get(history_count());
    } else if (isdigit((unsigned char)p[1])) {
        char *end;
        long n = strtol(p + 1, &end, 10);
        if (*end == '\0') h = history_get((int)n);
    } else {
        return NULL;
    }
    if (!h) {
        fprintf(stderr, "mysh: %s: event not found\n", p);
        return xstrdup("");
    }
    return xstrdup(h);
}

int main(int argc, char **argv) {
    char *cmd_string = NULL;
    if (argc >= 3 && !strcmp(argv[1], "-c")) {
        cmd_string = argv[2];
    } else if (argc >= 2) {
        if (!freopen(argv[1], "r", stdin)) {
            fprintf(stderr, "mysh: %s: %s\n", argv[1], strerror(errno));
            return 127;
        }
    }

    if (!cmd_string) shell_init();   /* -c never uses the terminal */

    if (cmd_string) {
        process_line(cmd_string);
        return shell_should_exit ? shell_exit_code : last_status;
    }

    char *line;
    while (!shell_should_exit) {
        jobs_reap();
        jobs_notify(shell_interactive);

        line = read_line();
        if (!line) {
            if (shell_interactive) puts("exit");
            break;
        }

        char *expanded = history_expand(line);
        if (expanded) {
            if (*expanded) puts(expanded);
            free(line);
            line = expanded;
        }
        if (shell_interactive) history_add(line);

        process_line(line);
        free(line);
    }

    shell_cleanup();
    return shell_should_exit ? shell_exit_code : last_status;
}
