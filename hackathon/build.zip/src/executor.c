/*
 * executor.c - runs parsed pipelines.
 *
 * Interactive job-control protocol (same as POSIX / glibc manual):
 *   - every pipeline gets its own process group (pgid = first child's pid)
 *   - setpgid() is called in BOTH parent and child to avoid a race
 *   - a foreground job is given the terminal with tcsetpgrp()
 *   - after it exits or stops the shell takes the terminal back and
 *     restores its own termios settings
 */
#include "shell.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static int apply_redirs(const Command *c) {
    int fd;
    if (c->in_file) {
        fd = open(c->in_file, O_RDONLY);
        if (fd < 0) {
            fprintf(stderr, "mysh: %s: %s\n", c->in_file, strerror(errno));
            return -1;
        }
        dup2(fd, STDIN_FILENO);
        close(fd);
    }
    if (c->out_file) {
        int fl = O_WRONLY | O_CREAT | (c->out_append ? O_APPEND : O_TRUNC);
        fd = open(c->out_file, fl, 0644);
        if (fd < 0) {
            fprintf(stderr, "mysh: %s: %s\n", c->out_file, strerror(errno));
            return -1;
        }
        dup2(fd, STDOUT_FILENO);
        close(fd);
    }
    if (c->err_file) {
        int fl = O_WRONLY | O_CREAT | (c->err_append ? O_APPEND : O_TRUNC);
        fd = open(c->err_file, fl, 0644);
        if (fd < 0) {
            fprintf(stderr, "mysh: %s: %s\n", c->err_file, strerror(errno));
            return -1;
        }
        dup2(fd, STDERR_FILENO);
        close(fd);
    }
    if (c->err_to_out) dup2(STDOUT_FILENO, STDERR_FILENO);
    return 0;
}

/* A builtin that runs inside the shell process (so cd, fg, exit work). */
static int run_builtin_in_shell(const Command *c) {
    int saved[3];
    for (int i = 0; i < 3; i++) saved[i] = fcntl(i, F_DUPFD_CLOEXEC, 10);
    int status;
    if (apply_redirs(c) < 0) {
        status = 1;
    } else {
        status = run_builtin(c->argc, c->argv);
        fflush(stdout);
    }
    for (int i = 0; i < 3; i++) {
        if (saved[i] >= 0) {
            dup2(saved[i], i);
            close(saved[i]);
        }
    }
    return status;
}

static void child_run(const Command *c, int in_fd, int out_fd, int close_fd,
                      pid_t pgid, int fg, int first_of_bg) {
    if (shell_interactive) {
        pid_t me = getpid();
        if (!pgid) pgid = me;
        setpgid(me, pgid);
        if (fg) tcsetpgrp(STDIN_FILENO, pgid);
    }
    signal(SIGINT, SIG_DFL);
    signal(SIGQUIT, SIG_DFL);
    signal(SIGTSTP, SIG_DFL);
    signal(SIGTTIN, SIG_DFL);
    signal(SIGTTOU, SIG_DFL);

    if (in_fd != STDIN_FILENO) {
        dup2(in_fd, STDIN_FILENO);
        close(in_fd);
    } else if (first_of_bg && !shell_interactive) {
        int nul = open("/dev/null", O_RDONLY);
        if (nul >= 0) {
            dup2(nul, STDIN_FILENO);
            close(nul);
        }
    }
    if (out_fd != STDOUT_FILENO) {
        dup2(out_fd, STDOUT_FILENO);
        close(out_fd);
    }
    if (close_fd >= 0) close(close_fd);

    if (apply_redirs(c) < 0) _exit(1);

    if (is_builtin(c->argv[0])) {
        int st = run_builtin(c->argc, c->argv);
        fflush(stdout);
        _exit(st);
    }
    execvp(c->argv[0], c->argv);
    int e = errno;
    if (e == ENOENT) {
        fprintf(stderr, "mysh: %s: command not found\n", c->argv[0]);
        _exit(127);
    }
    fprintf(stderr, "mysh: %s: %s\n", c->argv[0], strerror(e));
    _exit(e == EACCES || e == ENOEXEC ? 126 : 127);
}

/* Wait for job j in the foreground and convert the outcome to $?. */
int job_run_foreground(Job *j, int send_cont) {
    j->background = 0;
    if (shell_interactive) {
        tcsetpgrp(STDIN_FILENO, j->pgid);
        if (send_cont && j->has_tmodes)
            tcsetattr(STDIN_FILENO, TCSADRAIN, &j->tmodes);
    }
    if (send_cont) job_continue(j);

    job_wait(j, 0);

    if (shell_interactive) {
        tcsetpgrp(STDIN_FILENO, shell_pgid);
        if (j->state == JOB_STOPPED) {
            tcgetattr(STDIN_FILENO, &j->tmodes);
            j->has_tmodes = 1;
        }
        tcsetattr(STDIN_FILENO, TCSADRAIN, &shell_tmodes);
    }

    if (j->state == JOB_STOPPED) {
        j->background = 1; /* a stopped job lives in the table */
        j->notified = 1;
        fputc('\n', stdout);
        job_print(j, 0, 0);
        fflush(stdout);
        return 128 + SIGTSTP;
    }

    int status = j->exit_status;
    if (j->term_sig == SIGINT) {
        fputc('\n', stderr);
    } else if (j->term_sig && j->term_sig != SIGPIPE) {
        fprintf(stderr, "%s\n", strsignal(j->term_sig));
    }
    job_remove(j);
    return status;
}

static int launch_job(const Pipeline *p) {
    int n = p->ncmds;
    int fg = !p->background;
    pid_t *pids = xmalloc(n * sizeof(pid_t));
    pid_t pgid = 0;
    int in_fd = STDIN_FILENO;
    int launched = 0;

    for (int i = 0; i < n; i++) {
        int fds[2] = {-1, -1};
        int out_fd = STDOUT_FILENO;
        if (i < n - 1) {
            if (pipe(fds) < 0) {
                perror("mysh: pipe");
                break;
            }
            out_fd = fds[1];
        }
        fflush(NULL);
        pid_t pid = fork();
        if (pid < 0) {
            perror("mysh: fork");
            if (fds[0] >= 0) { close(fds[0]); close(fds[1]); }
            break;
        }
        if (pid == 0) {
            child_run(&p->cmds[i], in_fd, out_fd, fds[0], pgid, fg,
                      i == 0 && p->background);
            _exit(127); /* not reached */
        }
        if (!pgid) pgid = pid;
        if (shell_interactive) setpgid(pid, pgid);
        pids[launched++] = pid;
        if (in_fd != STDIN_FILENO) close(in_fd);
        if (out_fd != STDOUT_FILENO) close(out_fd);
        in_fd = fds[0];
    }
    if (in_fd != STDIN_FILENO) close(in_fd);

    if (launched == 0) {
        free(pids);
        return 1;
    }

    Job *j = job_create(pgid, p->text, pids, launched, p->background);
    last_bg_pid = p->background ? pids[launched - 1] : last_bg_pid;
    free(pids);

    if (p->background) {
        if (shell_interactive) {
            printf("[%d] %d\n", j->id, (int)last_bg_pid);
            fflush(stdout);
        }
        return 0;
    }
    return job_run_foreground(j, 0);
}

int run_pipeline(const Pipeline *p) {
    const Command *first = &p->cmds[0];
    int single_builtin = (p->ncmds == 1 && !p->background && is_builtin(first->argv[0]));

    if (!(single_builtin && strcmp(first->argv[0], "exit") == 0)) exit_warned = 0;
    if (single_builtin) return run_builtin_in_shell(first);
    return launch_job(p);
}
