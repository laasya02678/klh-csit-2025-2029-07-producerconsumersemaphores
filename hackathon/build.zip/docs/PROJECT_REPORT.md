# Project Report — Mini Linux Shell with Background Job Management

Mapped to the evaluation rubric.

## 1. Problem Definition (10)

**Problem.** Running one command at a time blocks the terminal. Long tasks (builds, downloads,
servers, backups) force users to open extra terminals. Unix solves this with *job control*, but the
mechanism (process groups, controlling terminals, signals, wait-status decoding) is one of the least
understood parts of the OS.

**Goal.** Build a Linux shell from system calls that lets a user:
1. run any command in the foreground or background (`&`);
2. suspend (Ctrl+Z), resume (`fg`, `bg`), list (`jobs`), signal (`kill`) and synchronise on (`wait`) jobs;
3. be notified when jobs finish or stop — without the shell ever freezing or being killed by job-control keys.

**Scope.** Pipelines, redirection, quoting/expansion, builtins and job control. Out of scope:
scripting constructs (`if/for/while`, functions), `&&/||`, here-docs.

**Success criteria.** Matches bash for the job-control scenarios in the test suite; zero zombies;
no sanitizer findings; shell survives Ctrl+C / Ctrl+Z.

## 2. Novelty and Innovation (15)

Beyond a textbook `fork/exec` shell (details in README):

| # | Innovation | Why it matters |
|---|---|---|
| 1 | **Asynchronous notifications at an idle prompt** (`poll` timeout + non-blocking reap) | Most toy shells only report on the next Enter; this behaves like a real shell |
| 2 | **Job-aware prompt** `mysh[2 running, 1 stopped]$` | Background state is always visible |
| 3 | **`jobs -l` with elapsed time and per-process states** for each pipeline stage | Observability beyond bash's default `jobs` |
| 4 | **Pipeline = single job**, state derived from member processes | Correct handling of `a \| b &` and partial failure |
| 5 | **Per-job `termios` save/restore** | Stopped full-screen programs (vim, less) resume with a sane terminal |
| 6 | **SIGTERM → SIGCONT** for stopped jobs | Prevents un-killable stopped jobs |
| 7 | **Lazy per-pipeline expansion + whole-line syntax pre-check** | Correct `$?` semantics *and* atomic syntax errors |
| 8 | **Signal-handler-free reaping** (poll-based) | Eliminates reentrancy/race bugs on the job list |
| 9 | **Shell-exit policy**: stopped-job warning, SIGHUP to jobs, `disown` exemption | Prevents orphaned or hung work |
| 10 | **Pseudo-terminal test harness** | Job control is normally untestable in CI; this types real Ctrl+Z / Ctrl+C |

## 3. Architecture Design (10)

See the diagrams and decision table in `README.md`. Summary:

* **Layered pipeline:** `main (REPL)` → `parser` → `executor` → `jobs` ← `builtins`.
* **Single shared header** defines the data types (`Command`, `Pipeline`, `Job`, `Proc`) and the narrow
  interface each module exposes; modules do not touch each other's internals.
* **Data model:** `Pipeline{Command[]}` (parse time) → `Job{Proc[]}` (run time). Jobs live in a
  singly linked list with increasing ids and a recency counter for `%+` / `%-`.
* **Process model:** one process group per pipeline; terminal ownership handed to the foreground
  group with `tcsetpgrp` and returned afterwards.
* **Error handling:** syscalls are checked; failures print `mysh: <what>: <strerror>` and set `$?`.

## 4. Implementation (20)

| File | Lines | Responsibility |
|---|---|---|
| `main.c` | ~250 | init, signal policy, REPL, prompt, async notices, `!!` |
| `parser.c` | ~440 | lexer, quoting, expansion, glob, incremental parser |
| `executor.c` | ~230 | pipes, fork/exec, redirections, foreground/background launch |
| `jobs.c` | ~310 | job table, state machine, specs, printing |
| `builtins.c` | ~420 | 13 builtins incl. 6 job-control commands |
| `util.c` | ~90 | memory helpers, history |

System calls used: `fork execvp pipe dup2 open close setpgid getpgrp tcsetpgrp tcgetpgrp tcgetattr
tcsetattr waitpid kill sigaction signal poll getcwd chdir isatty`.

Exit-status model follows POSIX: `128+signal` when killed (143 = SIGTERM, 137 = SIGKILL, 130 = SIGINT).

## 5. Testing (10)

| Suite | Count | Technique |
|---|---|---|
| `tests/run_tests.sh` | 67 | black-box; compares output and exit codes |
| `tests/test_jobcontrol.py` | 12 | runs the shell in a pseudo-terminal, sends Ctrl+Z / Ctrl+C |
| Sanitizers | — | scripted suite under `-fsanitize=address,undefined`: clean |

Bugs found by the tests and fixed:
* `$?` was expanded for the whole line *before* any command ran, so `kill %1; wait %1; echo $?`
  printed a stale value. Fixed with incremental, per-pipeline parsing.
* `wait` with no arguments left finished jobs in the table to be re-reported as `Done`.
* Redirect-only commands (`> file`) at end of line were silently accepted instead of rejected.

## 6. Documentation (10)

`README.md` (usage, features, architecture, design decisions, limitations), this report,
the in-shell `help` command, and a header comment in each source file stating the module's contract.

## 7. GitHub Repository (5)

```bash
cd mysh
git init && git add . && git commit -m "mysh: mini shell with background job management"
git branch -M main
git remote add origin https://github.com/<your-username>/mysh.git
git push -u origin main
```
Repo hygiene: tag `v1.0`, add a demo GIF to the README (record with `asciinema`), and a GitHub
Actions workflow running `make && make test`.

**Repository link:** `https://github.com/<your-username>/mysh`  ← replace with yours

## 8. Presentation (10) — suggested 10 slides

1. Title + one-line pitch
2. Problem: blocking terminals; why job control is hard
3. Live demo storyline (below)
4. Architecture diagram (from README)
5. Process groups & terminal ownership — who receives Ctrl+C?
6. Job state machine
7. Design decisions: no work in signal handlers, the `setpgid` race, lazy expansion
8. Novel features
9. Testing: PTY harness, 79 tests, sanitizers; a bug found and fixed
10. Business impact, limitations, future work, Q&A

**Demo script (~90 s):**
```
sleep 100 &            # background; note "[1] pid"
sleep 200              # foreground … press Ctrl+Z
jobs -l
bg %2
kill %1
fg %2                  # press Ctrl+C
echo $?                # 130
sleep 2 &              # wait at the idle prompt: "Done" appears by itself
```

## 9. Team Work (5)

Suggested split for a team of four (adjust to your team; keep real commits per member):

| Member | Ownership |
|---|---|
| A | Parser/lexer, expansion, syntax errors (`parser.c`) |
| B | Executor: pipes, redirection, process groups, terminal control (`executor.c`) |
| C | Job table + job-control builtins (`jobs.c`, `builtins.c`) |
| D | Test suites, CI, documentation, demo |

Practices: feature branches + pull requests, the shared header agreed first as the interface
contract, code review before merge, weekly integration builds.

## 10. Business Impact (5)

* **Developer/ops productivity:** background and resumable jobs in a single SSH session (builds,
  transfers, long migrations) without needing `screen`/`tmux`; `jobs -l` elapsed time doubles as a
  lightweight monitor.
* **Education & training:** a compact, readable reference implementation of POSIX job control
  (~1,900 lines) for teaching processes, signals, pipes and TTYs.
* **Embedded / containers:** a small binary with no dependencies, suited to constrained images.
* **Extensibility:** clean module boundaries make it a base for restricted or audited shells
  (command logging, allow-lists).

## Future work

`&&`/`||`, subshells, here-docs, `if/for/while`, aliases, readline-style editing and tab
completion, per-job CPU/memory accounting via `wait4()` rusage, `ulimit`, and a `nohup`-style
persistent job mode.
